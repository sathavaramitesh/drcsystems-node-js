export class Regex {
    public static readonly PASSWORD = /^(?=.*[0-9])(?=.*[~`!@#$%^&*-_])[a-zA-Z0-9!@#$%^&*-_~`]{6,20}$/;
}
