export class Tables {
  public static readonly USER = "users";
  public static readonly CHAT = "chats";
  public static readonly FRIEND = "friends";
  public static readonly REQUEST = "requests";
}