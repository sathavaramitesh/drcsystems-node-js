// import * as dotenv from 'dotenv';
import { App } from "./server";

new App();
