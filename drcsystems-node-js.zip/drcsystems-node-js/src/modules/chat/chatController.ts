import { Request, Response } from "express";
import { MessageType, Constants } from "../../config/constants";
import { ResponseBuilder } from "../../helpers/responseBuilder";
import { ChatUtils } from "./chatUtils";
import * as _ from "lodash";
import { FileUpload } from "../../helpers/fileUpload";
import { AuthUtils } from "../auth/authUtils"

export class ChatController {
    private chatUtils: ChatUtils = new ChatUtils();
    private authUtils: AuthUtils = new AuthUtils();

    public chatHistory = async (req: any, res: Response) => {
      const { id } = req._user;
        const result = await this.chatUtils.chatHistory(id, req.params.friendId);
        const response = ResponseBuilder.data(result);
        res.status(response.code).json(response);
      }

    public fileUpload = async (req: any, res: Response) => {
        let attachmentArray: any = [];
        const { attachment } = req.files as any;
        if (attachment.length > 0) {
          for (let i = 0; i < attachment.length; i++) {
            const uploadDetails = await FileUpload.fileUploading(attachment[i]) as any;
            const { attachmentId } = uploadDetails.data;
             let oneChat = await this.chatUtils.createChat({
                senderId: req.body._user.id,
                receiverId: req.body.senderId,
                text: attachmentId,
                type: MessageType.File
              })
            attachmentArray.push(attachmentId);
          }
        } else {
          const uploadDetails = await FileUpload.fileUploading(attachment) as any;
          const { attachmentId } = uploadDetails.data;
            let oneChat = await this.chatUtils.createChat({
              senderId: req.body._user.id,
              receiverId: req.body.senderId,
              text: attachmentId,
              type: MessageType.File
            })
          
          attachmentArray.push(attachmentId);
        }
        const response = ResponseBuilder.data(attachmentArray);
        res.status(response.code).json(response);
      }
    
}
