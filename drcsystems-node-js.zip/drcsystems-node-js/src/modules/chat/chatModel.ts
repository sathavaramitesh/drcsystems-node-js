import { IsNotEmpty, MaxLength, Validate, IsEmail } from "class-validator";
import { Constants } from "../../config/constants";
import { Model } from "../../model";

export class FileUploadModel extends Model{
    @IsNotEmpty()
    public attachment: File;
  
    constructor(file: any) {
        super();
        const {
            attachment
        } = file;
        this.attachment = attachment;
    }
  
  }


export class SenderIdModel extends Model {

    @IsNotEmpty()
    public senderId: number;
  
  
    constructor(body: any) {
      super();
      const {
        senderId
      } = body;
  
      this.senderId = senderId;
    }
  }

