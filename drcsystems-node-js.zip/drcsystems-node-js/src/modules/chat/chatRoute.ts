import { Router } from "express";
import { Validator } from "../../validate";
import { ChatController } from "./chatController";
import { FileUploadModel, SenderIdModel } from "./chatModel";

const router: Router = Router();
const v: Validator = new Validator();
const chatController = new ChatController();

router.get("/chat-history/:friendId", chatController.chatHistory);
router.post("/file-upload", v.fileValidate(FileUploadModel), v.validate(SenderIdModel), chatController.fileUpload);
export const ChatRoute: Router = router;
