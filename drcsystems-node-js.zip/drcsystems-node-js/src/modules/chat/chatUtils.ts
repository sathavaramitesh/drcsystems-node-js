import * as My from "jm-ez-mysql";
import { Tables } from "../../config/tables";
import { Utils } from "../../helpers/utils";
import { Constants } from "../../config/constants"
export class ChatUtils {

  public async createChat(data: Json) {
    return await My.insert(Tables.CHAT, data);
  }

  public async chatHistory(userId: number, friendId: number) {
    const model = `${Tables.CHAT} as c LEFT JOIN ${Tables.USER} as sender ON sender.id = c.senderId LEFT JOIN ${Tables.USER} as receiver ON receiver.id = c.receiverId`
    return await My.findAll(model, ['c.*, sender.firstName as senderfirstName, sender.lastName as senderLastName, receiver.firstName as receiverFirstName, receiver.lastName as receiverLastName'], '(c.senderId = ? AND c.receiverId = ?) OR (c.receiverId = ? AND c.senderId = ?)', [userId, friendId, userId, friendId])
  }


}
