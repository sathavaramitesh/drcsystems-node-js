import { Request, Response } from "express";
import { ResponseBuilder } from "../../helpers/responseBuilder";
import { UsersUtils } from "./usersUtils";
import { async } from "q";
import * as moment from "moment";
import * as _ from "lodash";
import { Jwt } from "../../helpers/jwt";
import { AuthUtils } from "../auth/authUtils"

export class UsersController {
    private usersUtils: UsersUtils = new UsersUtils();
    private authUtils: AuthUtils = new AuthUtils();


    public userList = async (req: Request, res: Response) => {
        const { id } = req._user;
        const inboxData = await this.usersUtils.userList(id);
        const response = ResponseBuilder.data(inboxData);
        res.status(response.code).json(response);
    }

    public sendFriendRequest = async (req: Request, res: Response) => {
        const { friendId } = req.params;
        const { id } = req._user;
        const inboxData = await this.usersUtils.sendFriendRequest(friendId, id);
        const response = ResponseBuilder.successMessage(req.t("FRIEND_REQUEST_SEND_SUCCESS"));
        res.status(response.code).json(response);
    }

    public acceptFriendRequest = async (req: Request, res: Response) => {
        const { friendId } = req.params;
        const { id } = req._user;
        const inboxData = await this.usersUtils.acceptFriendRequest(friendId, id);
        const response = ResponseBuilder.successMessage(req.t("FRIEND_REQUEST_ACCEPT_SUCCESS"));
        res.status(response.code).json(response);
    }

    public friendlist = async (req: Request, res: Response) => {
        const { id } = req._user;
        const inboxData = await this.usersUtils.friendlist(id);
        const response = ResponseBuilder.data(inboxData);
        res.status(response.code).json(response);
    }

    public requestList = async (req: Request, res: Response) => {
        const { id } = req._user;
        const inboxData = await this.usersUtils.requestList(id);
        const response = ResponseBuilder.data(inboxData);
        res.status(response.code).json(response);
    }

}
