import { ResponseBuilder } from "../../helpers/responseBuilder";
import { Utils } from "../../helpers/utils";
import { UsersUtils } from "./usersUtils";
import { async } from "q";
import * as _ from "lodash";

export class UsersMiddleware {
    private usersUtils: UsersUtils = new UsersUtils();

    public checkForFriendRequest = async (req, res, next) => {
        const { friendId } = req.params;
        const { id } = req._user;
        const result = await this.usersUtils.isCheckFriendRequest(id, friendId);
        if (result && result.id) {
            const error = ResponseBuilder.badRequest(req.t("ERR_ALREADY_SEND_FRIEND_REQUEST"));
            res.status(error.code).json({ error: error.error });
            return;
        } else {
           next();
        }
    }
}
