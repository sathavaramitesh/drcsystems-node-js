import { IsNotEmpty, MaxLength, Validate, IsEmail } from "class-validator";
import { Constants } from "../../config/constants";
import { Model } from "../../model";

export class FriendRequestModel extends Model {

    @IsNotEmpty()
    public friendId: number;

    constructor(body: any) {
        super();
        const {
            friendId,
        } = body;
        this.friendId = friendId;
    }

}

