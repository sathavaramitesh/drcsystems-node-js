import { Router } from "express";
import { Validator } from "../../validate";
import { UsersController } from "./usersController";
import { FriendRequestModel } from "./usersModel";
import { UsersMiddleware } from "./usersMiddleware";

const router: Router = Router();
const v: Validator = new Validator();
const usersController = new UsersController();
const usersMiddleware = new UsersMiddleware();


// User list 
const userList = [usersController.userList];
router.get("/userList", userList);

// send friend request
const sendFriendRequest = [usersMiddleware.checkForFriendRequest, usersController.sendFriendRequest];
router.get("/send-friend-request/:friendId", sendFriendRequest);

// accept friend request
const acceptFriendRequest = [usersController.acceptFriendRequest];
router.get("/accept-friend-request/:friendId", acceptFriendRequest);

// friend list request
const friendlist = [usersController.friendlist];
router.get("/friendList", friendlist);

// request list request
const requestList = [usersController.requestList];
router.get("/requestList", requestList);


export const UserRoute: Router = router;
