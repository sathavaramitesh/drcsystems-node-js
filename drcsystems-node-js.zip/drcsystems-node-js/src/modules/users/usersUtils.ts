import * as My from "jm-ez-mysql";
import { Tables } from "../../config/tables";
import { Utils } from "../../helpers/utils";
import { Constants } from "../../config/constants"
export class UsersUtils {

    public async getUserDetailByEmail(email: string) {
      const result = await My.first(Tables.USER,['id, firstName, lastName, email, createdAt, updatedAt'],
          `email = ?`, [email],
      );
      return result;
    }

  public async userList(userId: number){
     const model = `${Tables.USER} as u LEFT JOIN ${Tables.REQUEST} as r ON (r.userId = u.id) OR (r.friendId = u.id)`;
    return await My.findAll(model, ['u.*, r.status'], 'u.id != ?', [userId]);
  }

  public async sendFriendRequest(friendId: number, userId: number) {
    return await My.insert(Tables.REQUEST, {userId: userId, friendId: friendId});
  }

  public async isCheckFriendRequest(userId: number, friendId: number) {
   return await My.first(Tables.REQUEST, ['*'], 'userId = ? AND friendId = ?', [userId, friendId]);
  }

  public async acceptFriendRequest(friendId: number, userId: number) {
    return await My.update(Tables.REQUEST, {"status": Constants.ACCEPT}, '(userId = ? AND friendId = ?) OR (friendId = ? AND userId = ?)', [userId, friendId, userId, friendId]);
  }

  public async friendlist(userId: number){
    const model = `${Tables.USER} as u LEFT JOIN ${Tables.REQUEST} as r ON (r.userId = u.id AND r.userId != ${userId}) OR (r.friendId = u.id AND r.friendId != ${userId}) `
    return await My.findAll(model, ['u.*, r.status'], 'r.userId = ? OR r.friendId = ?', [userId, userId]);
  }

  public async requestList(userId: number){
    const model = `${Tables.USER} as u LEFT JOIN ${Tables.REQUEST} as r ON r.userId = u.id`;
    return await My.findAll(model, ['u.*, r.status'], 'r.friendId = ?', [userId]);
  }

}
