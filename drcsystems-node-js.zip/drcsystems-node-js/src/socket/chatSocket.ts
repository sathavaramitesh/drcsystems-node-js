import { Log } from "../helpers/logger";
import { MemCache } from "../helpers/memCache";
import { ChatSocketEvents } from "./chatSocketEvents";
import { Constants } from "../config/constants";
import { ChatSocketUtils } from "./chatSocketUtils";

export class ChatSocket {
  private logger = Log.getLogger();
  private chatUtils = new ChatSocketUtils();

  public init(io) {
    const nsp = io.of("/chat");
    nsp.use(async (socket, next) => {
      let token;
      if (socket.handshake.headers['x-auth-token']) {
        token = socket.handshake.headers['x-auth-token'];
      } else if (socket.handshake.query['x-auth-token']) {
        token = socket.handshake.query['x-auth-token'];
      }
      if (token) {
        try {
          const { user } = await this.chatUtils.loadSocketUser(token) as any;
          socket.user = user;
          next();
        } catch (error) {
          this.logger.debug("Could not decode token");
        }
      } else {
        this.logger.debug("Token : get lost!! You don't have token");
      }
    })
      .on(Constants.SOCKET_EVENTS.CONNECT, (socket) => {
        try {
          MemCache.hset(process.env.CHAT_SOCKET, socket.user.id, socket.id);
          const chatSocketEvents = new ChatSocketEvents();
          chatSocketEvents.init(nsp, socket);
        } catch (err) {
          this.logger.error(err);
        }
      });
  }
}
