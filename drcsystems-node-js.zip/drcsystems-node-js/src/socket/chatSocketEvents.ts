import * as l10n from "jm-ez-l10n";
import { Constants } from "../config/constants";
import { plainToClass } from "class-transformer";
import * as _ from "lodash";
import { validate } from "class-validator";
import { MemCache } from "../helpers/memCache";
import { Validator } from "./chatSocketValidator";
import { ResponseBuilder } from "../helpers/responseBuilder";
import { ChatUtils } from "../modules/chat/chatUtils";
export class ChatSocketEvents {
  private chatUtils = new ChatUtils();
  private validatorMapping = new Validator.ValidatorMapping();
  private nsp;
  private socket;

  public init(nsp, socket) {
    this.nsp = nsp;
    this.socket = socket;
    // this.mwValidator();
    this.listenToEvents();
  }

  private listenToEvents() {
    this.sendMessage();
    this.onDisconnect();
  }

  private sendMessage() {
    this.socket.on('send-message', async (data: Validator.sendMessage) => {
      const reqData = {
        senderId: this.socket.user.id,
        receiverId: data.senderId,
        text: data.text,
        type: data.type

      }
      const chat: ResponseBuilder = await this.chatUtils.createChat(reqData);
      const recSocket = MemCache.hget(process.env.CHAT_SOCKET, `${data.senderId}`);
      this.nsp.to(recSocket).emit("receiver-message", {
        senderId: this.socket.user.id,
        receiverId: data.senderId,
        text: data.text,
        fullName: this.socket.user.fullName,
        type: data.type
      });
      return;
    });
  }

  private onDisconnect() {
    this.socket.on(Constants.SOCKET_EVENTS.DISCONNECT, async () => {
      const me = this.socket.user.id;
      MemCache.hdel(process.env.CHAT_SOCKET, me);
    });
  }
}
