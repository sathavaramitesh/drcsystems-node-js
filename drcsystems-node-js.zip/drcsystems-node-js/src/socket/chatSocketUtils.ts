import * as My from "jm-ez-mysql";
import { Log } from "../helpers/logger";
import { Middleware } from "../middleware";
import { Tables } from "../config/tables";
import { Constants } from "../config/constants";

export class ChatSocketUtils {
  private logger = Log.getLogger();
  private middleware = new Middleware();

  public loadSocketUser(token: string) {
    return new Promise((resolve, reject) => {
      this.middleware.loadSocketUser(token, (result) => {
        if (result.error) {
          this.logger.error(result.error);
          reject(result.message);
        } else {
          resolve(result.data);
        }
      });
    });
  }

}
