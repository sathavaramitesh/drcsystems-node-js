import { IsEnum, IsNotEmpty, IsOptional, IsPositive, IsUUID, MaxLength, MinLength } from "class-validator";

// tslint:disable-next-line:no-namespace
export namespace Validator {
  export class ValidatorMapping {
    public mapping(eventName: string) {
      return {
        emitNewMessage: sendMessage,
        emitJoinRoom: JoinRoom,
        emitGroupMessage: NewGroupMessage,
        emitDeleteGroup: JoinRoom,
      }[eventName];
    }
  }

  export class sendMessage {
    @IsNotEmpty()
    public senderId: number;
  
    @IsNotEmpty()
    public text: any;
   
    @IsNotEmpty()
    public type: any;

   
  }

  export class JoinRoom {
    @IsNotEmpty()
    groupId: number
  }
  export class BroadCastMessage {
    @IsNotEmpty()
    groupId: number;

    @IsNotEmpty()
    text: any;

    @IsNotEmpty()
    public type: any;
  }
  export class ChatHistory {
    @IsNotEmpty()
    senderId: number;
  }

  export class NewGroupMessage {
    @IsNotEmpty()
    // @IsUUID()
    public uid: string;

    @MaxLength(1000)
    @IsNotEmpty()
    public message: string;

    @IsPositive()
    public groupId: number;


    @IsEnum(["text", "info", "paymenttransfer"])
    public messageType: string;
    public ts: string;
    public sender: number;
    // public metaData: string;
  }
}


